using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class GameManager : MonoBehaviour
{
    public Text pillExist;
    public GameObject winText;
    public Transform pillHolder;

    int pill;
    // Start is called before the first frame update
    void Start()
    {
        winText.SetActive(false);
        pill = pillHolder.childCount;
    }

    
    public void AddScore()
    {
        pill--;
        pillExist.text = "Pill: " + pill;
        

        if (pill == 0)
        { 
            winText.SetActive(true);
            StartCoroutine(NextStage());
        }
    }

    IEnumerator NextStage()
    {   
        yield return new WaitForSeconds(2f);
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}
