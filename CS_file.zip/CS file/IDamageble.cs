using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IDamageble : MonoBehaviour
{
    public interface IDamageable
    {

        void TakeHit(float damage, RaycastHit hit);

    }
}
