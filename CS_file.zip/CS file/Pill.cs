using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using static IDamageble;

[RequireComponent(typeof(NavMeshAgent))]

public class Pill : MonoBehaviour, IDamageable
{
    public float startingHealth;
    public float health;
    public bool dead;

    public event System.Action OnDeath;
    NavMeshAgent pathfinder;
    Transform target;

    void Start()
    {
        health = startingHealth;

        /* pathfinder = GetComponent<NavMeshAgent>();*/
        /*target = GameObject.FindGameObjectWithTag("Player").transform;

        StartCoroutine(UpdatePath());*/
    }

    public void TakeHit(float damage, RaycastHit hit)
    {
        health -= damage;

        if (health <= 0 && !dead)
        {
            Die();
        }
    }

    public void Die()
    {
        dead = true;
        if (OnDeath != null)
        {
            OnDeath();
        }
        Die_SetInactive();
        GameObject.DestroyImmediate(gameObject);
        FindObjectOfType<GameManager>().AddScore();
    }

    public void Die_SetInactive()
    {
        if (health <= 0)
        {
            gameObject.SetActive(false);
        }
    }
    void Update()
    {

    }

    /*IEnumerator UpdatePath()
    {
        float refreshRate = .1f;

        while (target != null)
        {
            Vector3 targetPosition = new Vector3(target.position.x, 0, target.position.z);
            if (!dead)
            {
                pathfinder.SetDestination(targetPosition);
            }
            yield return new WaitForSeconds(refreshRate);
        }
    }*/


}
