using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public float soomothFollowSpeed;
    Vector3 offset;
    public Transform target;
    // Start is called before the first frame update
    void Start()
    {
        offset = target.position - transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 targetPos = target.position - offset;
        transform.position = Vector3.Lerp(transform.position,targetPos, soomothFollowSpeed);
    }
}
